# Kit Chatbot de Suporte PT — Qwen

Produto digital: prompts + fluxos para atendimento em português (e-commerce / SaaS).

## O que inclui
1. `system-prompt.md` — system prompt base (tom BR, escalonamento humano)
2. `fluxos.md` — 8 intenções (pedido, prazo, troca, boleto, cancelamento, bug, upgrade, humano)
3. `few-shots.md` — 12 exemplos entrada→resposta
4. `qa-checklist.md` — checklist antes de publicar o bot

## Preço
**R$ 50** via PIX (EMV `_2` / `pix_copia_cola_2`).

Após pagar: e-mail **z99003303@gmail.com** com “Kit Chatbot PT” + comprovante. Entrega zip/markdown no mesmo dia útil.

Landing: https://ziuluiziul.github.io/qwen-assistente-pix/kit-chatbot-pt/
