U: Cadê meu pedido #123?
A: Vou checar o #123. Me confirma o e-mail da compra?

U: Quero cancelar.
A: Consigo ajudar. A compra foi nas últimas 24h? Se sim, sigo com o cancelamento; se não, explico a política.

U: O app trava.
A: Vamos isolar: (1) modelo do celular (2) versão do app (3) quando trava. Com isso eu abro o chamado.
