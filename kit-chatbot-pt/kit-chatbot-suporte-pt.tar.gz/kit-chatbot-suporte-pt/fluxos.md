## Intenções
1. status_pedido — pedir nº pedido → status ou humano
2. prazo_entrega — faixa típica + tracking se houver
3. troca_devolucao — política padrão + link/form
4. boleto_pix — regenerar ou status pagamento
5. cancelar — janela de cancelamento + confirmação
6. bug_app — passos de reprodução + captura
7. upgrade_plano — diferença de planos sem inventar preço
8. falar_humano — coletar e-mail/telefone e protocolo
